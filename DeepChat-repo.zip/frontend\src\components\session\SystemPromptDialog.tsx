import { useEffect, useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import {
  DEFAULT_SYSTEM_PROMPT,
  setDraftSystemPrompt,
  setSessionSystemPrompt,
  useChatStore,
} from '../../services/chat/store.js'
import { Button } from '../base/Button.js'
import { Modal } from '../base/Modal.js'
import { closeSystemPromptDialog, useSystemPromptDialog } from './systemPromptDialogState.js'
import styles from './SystemPromptDialog.module.css'

/**
 * 系统提示词编辑。两种入口共用：
 * - 会话菜单：改某个已存在的会话；
 * - 新建会话：sessionId 为 null，改的是「下一条消息将创建的会话」，默认填入默认提示词。
 * 内容等于默认提示词时按缺省处理，不落库，保持「未自定义」的状态。
 */
export const SystemPromptDialog = () => {
  const t = useTranslate()
  const open = useSystemPromptDialog((state) => state.open)
  const sessionId = useSystemPromptDialog((state) => state.sessionId)
  const stored = useChatStore((state) =>
    sessionId ? (state.sessionCache[sessionId]?.systemPrompt ?? '') : ''
  )
  const [value, setValue] = useState('')
  const [busy, setBusy] = useState(false)

  const isDraft = sessionId === null
  const initial = isDraft ? DEFAULT_SYSTEM_PROMPT : stored || DEFAULT_SYSTEM_PROMPT

  useEffect(() => {
    if (open) {
      setValue(initial)
    }
    // 只在打开或目标切换时重置，避免输入过程中被覆盖
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, sessionId])

  if (!open) {
    return null
  }

  const save = async () => {
    if (busy) {
      return
    }
    setBusy(true)
    try {
      const trimmed = value.trim()
      const normalized = trimmed === DEFAULT_SYSTEM_PROMPT ? '' : trimmed
      if (isDraft) {
        setDraftSystemPrompt(normalized)
      } else {
        await setSessionSystemPrompt(sessionId, normalized)
      }
      closeSystemPromptDialog()
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal
      title={isDraft ? t('systemPromptNewChatTitle') : t('systemPromptTitle')}
      closable
      className={styles.dialog}
      onClose={closeSystemPromptDialog}
      footer={
        <>
          <Button variant="outlined" size="m" onClick={closeSystemPromptDialog} disabled={busy}>
            {t('cancel')}
          </Button>
          <Button size="m" onClick={() => void save()} disabled={busy}>
            {t('save')}
          </Button>
        </>
      }
    >
      <div className={styles.hint}>
        {isDraft ? t('systemPromptNewChatHint') : t('systemPromptHint')}
      </div>
      <textarea
        className={styles.input}
        value={value}
        rows={8}
        spellCheck={false}
        placeholder={t('systemPromptPlaceholder')}
        onChange={(event) => setValue(event.target.value)}
      />
    </Modal>
  )
}
