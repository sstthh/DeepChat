import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { closeImageViewer, useImageViewer } from './imageViewerState.js'
import styles from './ImageViewer.module.css'

const MIN_SCALE = 1
const MAX_SCALE = 5
const DOUBLE_TAP_SCALE = 2.5

type Point = { x: number; y: number }

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value))
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y)
const midpoint = (a: Point, b: Point): Point => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 })

type Pinch = {
  startDistance: number
  startScale: number
  startCenter: Point
  startOffset: Point
}

type Pan = {
  startPoint: Point
  startOffset: Point
}

/**
 * 全屏看图。页面本身禁用了缩放，所以双指缩放和拖动在这里用指针事件单独实现：
 * 两指捏合缩放（1x–5x）、放大后单指拖动、双击切换 1x / 2.5x、点背景关闭。
 */
export const ImageViewer = () => {
  const url = useImageViewer((state) => state.url)
  const name = useImageViewer((state) => state.name)
  const [scale, setScale] = useState(1)
  const [offset, setOffset] = useState<Point>({ x: 0, y: 0 })
  const [gesturing, setGesturing] = useState(false)
  const pointers = useRef(new Map<number, Point>())
  const pinch = useRef<Pinch | null>(null)
  const pan = useRef<Pan | null>(null)
  const moved = useRef(false)

  // 换图或关闭时复位
  useEffect(() => {
    setScale(1)
    setOffset({ x: 0, y: 0 })
    pointers.current.clear()
    pinch.current = null
    pan.current = null
  }, [url])

  useEffect(() => {
    if (!url) {
      return
    }
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeImageViewer()
      }
    }
    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [url])

  if (!url) {
    return null
  }

  const list = () => [...pointers.current.values()]

  const onPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId)
    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY })
    moved.current = false
    const points = list()
    if (points.length === 2) {
      pinch.current = {
        startDistance: Math.max(1, distance(points[0], points[1])),
        startScale: scale,
        startCenter: midpoint(points[0], points[1]),
        startOffset: offset,
      }
      pan.current = null
      setGesturing(true)
    } else if (points.length === 1) {
      pan.current = {
        startPoint: points[0],
        startOffset: offset,
      }
      setGesturing(true)
    }
  }

  const onPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!pointers.current.has(event.pointerId)) {
      return
    }
    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY })
    moved.current = true
    const points = list()

    if (points.length >= 2 && pinch.current) {
      const current = pinch.current
      const ratio = distance(points[0], points[1]) / current.startDistance
      const next = clamp(current.startScale * ratio, MIN_SCALE, MAX_SCALE)
      const center = midpoint(points[0], points[1])
      setScale(next)
      setOffset({
        x: current.startOffset.x + (center.x - current.startCenter.x),
        y: current.startOffset.y + (center.y - current.startCenter.y),
      })
      return
    }

    if (points.length === 1 && pan.current && scale > 1) {
      const point = points[0]
      setOffset({
        x: pan.current.startOffset.x + (point.x - pan.current.startPoint.x),
        y: pan.current.startOffset.y + (point.y - pan.current.startPoint.y),
      })
    }
  }

  const onPointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    pointers.current.delete(event.pointerId)
    const remaining = list()
    if (remaining.length < 2) {
      pinch.current = null
    }
    if (remaining.length === 1) {
      pan.current = { startPoint: remaining[0], startOffset: offset }
    }
    if (remaining.length === 0) {
      pan.current = null
      setGesturing(false)
      // 没拖动、也没放大时，点一下背景就关闭
      if (!moved.current && scale <= 1.02) {
        closeImageViewer()
      }
    }
  }

  const onDoubleClick = () => {
    if (scale > 1) {
      setScale(1)
      setOffset({ x: 0, y: 0 })
    } else {
      setScale(DOUBLE_TAP_SCALE)
    }
  }

  return createPortal(
    <div
      className={styles.overlay}
      role="dialog"
      aria-modal="true"
      aria-label={name}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      onDoubleClick={onDoubleClick}
    >
      <img
        className={styles.image}
        src={url}
        alt={name}
        draggable={false}
        style={{
          transform: `translate(${offset.x}px, ${offset.y}px) scale(${scale})`,
          transition: gesturing ? 'none' : 'transform 160ms ease',
        }}
      />
      {scale > 1 ? (
        <button
          type="button"
          className={styles.reset}
          onClick={(event) => {
            event.stopPropagation()
            setScale(1)
            setOffset({ x: 0, y: 0 })
          }}
        >
          还原
        </button>
      ) : null}
    </div>,
    document.body
  )
}
