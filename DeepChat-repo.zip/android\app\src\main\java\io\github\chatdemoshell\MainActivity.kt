package io.github.chatdemoshell

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.format.Formatter
import android.util.Base64
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * chat-demo 的原生外壳，两种运行模式：
 *
 * 1. 内置模式（默认）：加载 app/src/main/assets/www 里的静态站点，断网可用，
 *    由 [WebViewAssetLoader] 挂在 https://appassets.androidplatform.net 下，
 *    这样页面拿到的才是正常 https origin，localStorage / IndexedDB 才稳。
 * 2. 远程模式：构建时加 -PchatDemoUrl=https://cdn.deepseek.com/chat-demo/，
 *    壳直接加载线上版本，永远最新，代价是必须联网。
 */
class MainActivity : Activity() {

    companion object {
        private const val ASSET_HOST = "appassets.androidplatform.net"
        private const val ASSET_START_URL = "https://$ASSET_HOST/assets/www/index.html"
        private const val REQ_FILE_CHOOSER = 1001
        private const val REQ_MIC = 1002
        private const val REQ_CAPTURE = 1003
        /** 拍照后本地压缩到的长边上限，控制 base64 体积 */
        private const val MAX_CAPTURE_SIDE = 2048

        /**
         * 把页面背景色同步到系统状态栏 / 导航栏，切深色主题时不会出现白边。
         * 页面由 chat-demo 自己管理主题，这里不猜它的实现，只每 1.5 秒读一次
         * body 的计算背景色，变了才回传。
         */
        /** 询问页面是否消费返回键：true 表示已处理（关弹窗 / 收抽屉 / 回新对话） */
        private const val BACK_SCRIPT =
            "(function(){try{return !!(window.__deepChatBack && window.__deepChatBack())}catch(e){return true}})()"

        /**
         * 一次性诊断：在本机 WebView 里跑 21 次小事务，量出 IndexedDB 单次提交的成本。
         * 结果经 AndroidBridge.reportBench 弹出来，装好后第一次加载页面时自动跑一次。
         */
        private const val BENCH_SCRIPT = """
            (async function () {
              try {
                var open = await new Promise(function (resolve, reject) {
                  var request = indexedDB.open('__bench', 1);
                  request.onupgradeneeded = function () {
                    request.result.createObjectStore('s', { keyPath: 'id' });
                  };
                  request.onsuccess = function () { resolve(request.result); };
                  request.onerror = function () { reject(request.error); };
                });
                function put(value) {
                  return new Promise(function (resolve, reject) {
                    var tx = open.transaction('s', 'readwrite');
                    tx.objectStore('s').put(value);
                    tx.oncomplete = function () { resolve(); };
                    tx.onerror = function () { reject(tx.error); };
                  });
                }
                await put({ id: 'warm', v: 'x' });
                var started = performance.now();
                for (var i = 0; i < 20; i++) {
                  await put({ id: 'i' + i, v: 'xxxxxxxxxxxxxxxx' });
                }
                var per = (performance.now() - started) / 20;
                open.close();
                indexedDB.deleteDatabase('__bench');
                AndroidBridge.reportBench(per.toFixed(1));
              } catch (error) {
                AndroidBridge.reportBench('ERR ' + String(error));
              }
            })();
        """

        private const val THEME_SCRIPT = """            (function () {
              if (window.__chatDemoChrome) { return; }
              window.__chatDemoChrome = true;
              var last = '';
              function report() {
                var bg = getComputedStyle(document.body).backgroundColor || '';
                var m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
                if (!m) { return; }
                var hex = '#';
                for (var i = 1; i <= 3; i++) {
                  var v = parseInt(m[i], 10).toString(16);
                  hex += v.length === 1 ? '0' + v : v;
                }
                if (hex !== last) { last = hex; AndroidBridge.setChromeColor(hex); }
              }
              report();
              setInterval(report, 1500);
            })();
        """
    }

    private val remoteUrl: String = BuildConfig.CHAT_DEMO_URL.trim()
    private val startUrl: String = remoteUrl.ifBlank { ASSET_START_URL }

    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingMicRequest: PermissionRequest? = null
    /** 上一次按返回键的时间，用于双击退出 */
    private var lastBackAt = 0L
    /** 系统相机正在写入的目标文件 */
    private var pendingCapture: File? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
            setBackgroundColor(Color.WHITE)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            settings.apply {
                javaScriptEnabled = true
                // chat-demo 的会话和附件原件都放在 IndexedDB / localStorage
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = true
                // 回复朗读走 Web Audio，不需要用户手势也能播
                mediaPlaybackRequiresUserGesture = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = false
                textZoom = 100
                userAgentString = "$userAgentString ChatDemoShell/1.1"
            }
            // 导出 ZIP 走 blob:，DownloadListener 拿不到内容，需要这个桥接把字节传回原生
            addJavascriptInterface(Bridge(), "AndroidBridge")
            webViewClient = AssetClient()
            webChromeClient = ChromeClient()
            setDownloadListener { url, _, _, mimeType, _ -> handleDownload(url, mimeType) }
        }

        setContentView(webView)
        setupEdgeToEdge()
        if (savedInstanceState == null) {
            webView.loadUrl(startUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    /**
     * 边到边：状态栏和导航栏透明，页面背景一直铺到屏幕四边，不再有一条系统色的横条。
     * 内容通过 --safe-area-top/bottom 留出安全距离，避免压在状态栏图标下面。
     */
    @Suppress("DEPRECATION")
    private fun setupEdgeToEdge() {
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    /** 把系统栏高度换算成 CSS 像素交给页面，页面据此留白 */
    @Suppress("DEPRECATION")
    private fun safeAreaScript(): String {
        val insets = window.decorView.rootWindowInsets
        val density = resources.displayMetrics.density.takeIf { it > 0f } ?: 1f
        val top = (insets?.systemWindowInsetTop ?: 0) / density
        val bottom = (insets?.systemWindowInsetBottom ?: 0) / density
        val topText = String.format(Locale.US, "%.1f", top)
        val bottomText = String.format(Locale.US, "%.1f", bottom)
        return "try{var d=document.documentElement;" +
            "if(d){d.style.setProperty('--safe-area-top','${topText}px');" +
            "d.style.setProperty('--safe-area-bottom','${bottomText}px');}}catch(e){}"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    /** 应用内部页面：内置 origin，或（远程模式下）deepseek 自己的域名 */
    private fun isInternal(uri: Uri): Boolean {
        val host = uri.host ?: return false
        if (host == ASSET_HOST) return true
        if (remoteUrl.isBlank()) return false
        return host == "deepseek.com" || host.endsWith(".deepseek.com")
    }

    /** 把 assets 里的文件喂给 WebView，其余请求原样放行到网络 */
    private inner class AssetClient : WebViewClient() {
        override fun shouldInterceptRequest(
            view: WebView,
            request: WebResourceRequest
        ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

        override fun shouldOverrideUrlLoading(
            view: WebView,
            request: WebResourceRequest
        ): Boolean {
            if (isInternal(request.url)) return false
            // 会话里点到的外链、引用来源，交给系统浏览器
            return openExternally(request.url)
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            // 尽早注入安全区，避免内容先压到状态栏下面再跳一下
            view.evaluateJavascript(safeAreaScript(), null)
        }

        override fun onPageFinished(view: WebView, url: String) {
            super.onPageFinished(view, url)
            view.evaluateJavascript(safeAreaScript(), null)
            view.evaluateJavascript(THEME_SCRIPT.trimIndent(), null)

            // 装好后首次加载跑一次 IndexedDB 基准，用来定位导入慢在哪一层
            val prefs = getSharedPreferences("diag", MODE_PRIVATE)
            if (remoteUrl.isNotBlank() && !prefs.getBoolean("idb_bench", false)) {
                prefs.edit().putBoolean("idb_bench", true).apply()
                view.evaluateJavascript(BENCH_SCRIPT.trimIndent(), null)
            }
        }
    }

    private inner class ChromeClient : WebChromeClient() {

        /** 附件「上传」按钮：系统文件选择器 */
        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            fileChooserCallback?.onReceiveValue(null)
            fileChooserCallback = filePathCallback

            val intent = try {
                fileChooserParams?.createIntent()
            } catch (_: Exception) {
                null
            } ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }

            return try {
                startActivityForResult(intent, REQ_FILE_CHOOSER)
                true
            } catch (_: ActivityNotFoundException) {
                fileChooserCallback = null
                false
            }
        }

        /** 语音输入：getUserMedia 会先走到这里，再到 onPermissionRequest */
        override fun onPermissionRequest(request: PermissionRequest) {
            val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
            if (!wantsAudio) {
                request.deny()
                return
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            } else {
                pendingMicRequest = request
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_CAPTURE) {
            val target = pendingCapture
            pendingCapture = null
            if (resultCode == RESULT_OK && target != null && target.exists() && target.length() > 0) {
                deliverCapture(target)
            }
            return
        }
        if (requestCode == REQ_FILE_CHOOSER) {
            val callback = fileChooserCallback
            fileChooserCallback = null
            if (callback == null) return
            val picked = readPickedUris(resultCode, data)
            if (picked == null) {
                callback.onReceiveValue(null)
                return
            }
            // 复制可能很大，放在后台线程；WebView 会一直等 onReceiveValue。
            Thread {
                val staged = picked.map { stagePickedFile(it) ?: it }.toTypedArray()
                runOnUiThread { callback.onReceiveValue(staged) }
            }.start()
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    /**
     * 文件选择器给的是 content:// URI，页面每次 slice() 都要跨进程向 DocumentsProvider 取数据。
     * 这里整份复制进应用私有目录，页面随后读到的是本地文件；同时把复制耗时打到屏幕上，
     * 用来判断慢在「读文件」还是「写数据库」。
     */
    private fun stagePickedFile(uri: Uri): Uri? {
        return try {
            val rawName = queryDisplayName(uri) ?: return null
            // 只给历史归档做原生暂存：页面读大 zip 时走 SAF 极慢。
            // 其它附件保持原始 URI —— 复制会改掉文件名，扩展名校验就过不去了。
            if (!rawName.endsWith(".zip", ignoreCase = true)) {
                return null
            }
            val dir = File(cacheDir, "imports").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val target = File(dir, sanitize(rawName))

            val started = System.currentTimeMillis()
            val input = contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("打不开所选文件")
            input.use { source ->
                target.outputStream().use { sink -> source.copyTo(sink, 256 * 1024) }
            }
            val elapsed = System.currentTimeMillis() - started
            val kb = target.length() / 1024.0
            toast(
                String.format(
                    Locale.US,
                    "读文件：%.0f KB，用时 %.2f 秒",
                    kb,
                    elapsed / 1000.0
                )
            )
            FileProvider.getUriForFile(this, "$packageName.fileprovider", target)
        } catch (error: Exception) {
            toast("复制失败，改用原文件：${error.message}")
            null
        }
    }

    /**
     * 用系统相机拍照：声明 EXTRA_OUTPUT 才能拿到原图（否则只有一张缩略图）。
     * 不申请 CAMERA 权限——相机由系统应用负责，我们只接收它写出的文件。
     */
    private fun launchCamera() {
        val dir = File(cacheDir, "captures").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val target = File(dir, "capture.jpg")
        val uri = try {
            FileProvider.getUriForFile(this, "$packageName.fileprovider", target)
        } catch (error: Exception) {
            toast(getString(R.string.camera_failed, error.message ?: ""))
            return
        }
        pendingCapture = target
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, REQ_CAPTURE)
        } catch (_: ActivityNotFoundException) {
            pendingCapture = null
            toast(getString(R.string.camera_missing))
        }
    }

    /** 读照片、按长边压到 2048、转 base64 data URL 交给页面 */
    private fun encodeCapture(file: File): Pair<String, String>? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_CAPTURE_SIDE) {
                sample *= 2
            }
            var bitmap = BitmapFactory.decodeFile(
                file.absolutePath,
                BitmapFactory.Options().apply { inSampleSize = sample }
            ) ?: return null
            val longest = max(bitmap.width, bitmap.height)
            if (longest > MAX_CAPTURE_SIDE) {
                val ratio = MAX_CAPTURE_SIDE.toFloat() / longest
                bitmap = Bitmap.createScaledBitmap(
                    bitmap,
                    max(1, (bitmap.width * ratio).toInt()),
                    max(1, (bitmap.height * ratio).toInt()),
                    true
                )
            }
            val bytes = java.io.ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 88, bytes)
            val base64 = Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)
            val name = "photo-${System.currentTimeMillis()}.jpg"
            "data:image/jpeg;base64,$base64" to name
        } catch (_: Exception) {
            null
        } catch (_: OutOfMemoryError) {
            null
        }
    }

    /** 把拍到的照片交回页面；页面用 File 构造出附件 */
    private fun deliverCapture(file: File) {
        Thread {
            val encoded = encodeCapture(file)
            runOnUiThread {
                if (encoded == null) {
                    toast(getString(R.string.camera_failed, ""))
                    return@runOnUiThread
                }
                val script = "window.__deepChatPhoto && window.__deepChatPhoto(" +
                    "${JSONObject.quote(encoded.first)}, ${JSONObject.quote(encoded.second)})"
                if (::webView.isInitialized) {
                    webView.evaluateJavascript(script, null)
                }
            }
        }.start()
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    } catch (_: Exception) {
        null
    }

    private fun readPickedUris(resultCode: Int, data: Intent?): Array<Uri>? {
        if (resultCode != RESULT_OK || data == null) return null
        data.clipData?.let { clip ->
            return Array(clip.itemCount) { clip.getItemAt(it).uri }
        }
        return data.data?.let { arrayOf(it) }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_MIC) return
        val request = pendingMicRequest
        pendingMicRequest = null
        if (request == null) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
        } else {
            // 永久拒绝后系统不会再弹窗，只能引导去设置
            val permanent = !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)
            Toast.makeText(
                this,
                if (permanent) R.string.mic_denied_settings else R.string.mic_denied,
                Toast.LENGTH_LONG
            ).show()
            request.deny()
        }
    }

    /**
     * chat-demo 导出历史时执行的是 `a.download = name; a.click()`，URL 是 blob:。
     * WebView 的 DownloadListener 只给得到 blob URL、拿不到数据，所以反向注入 JS
     * 把 blob 读成 base64，再经 JavascriptInterface 写进系统「下载」目录。
     */
    private fun handleDownload(url: String, mimeType: String?) {
        if (!url.startsWith("blob:") && !url.startsWith("data:")) {
            openExternally(Uri.parse(url))
            return
        }
        val name = "chat-demo-export-${
            SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        }.zip"
        val script = """
            (function () {
              fetch(__URL__).then(function (r) { return r.blob(); }).then(function (b) {
                var reader = new FileReader();
                reader.onload = function () {
                  var s = String(reader.result);
                  AndroidBridge.saveBase64(__NAME__, b.type || 'application/octet-stream', s.substring(s.indexOf(',') + 1));
                };
                reader.onerror = function () { AndroidBridge.reportError('read blob failed'); };
                reader.readAsDataURL(b);
              }).catch(function (e) { AndroidBridge.reportError(String(e)); });
            })();
        """.trimIndent()
            .replace("__URL__", JSONObject.quote(url))
            .replace("__NAME__", JSONObject.quote(name))
        webView.evaluateJavascript(script, null)
    }

    private inner class Bridge {

        /** IndexedDB 基准结果 */
        @JavascriptInterface
        fun reportBench(value: String) {
            toast("本机 IndexedDB 单次事务：$value ms")
        }

        /** 调起系统相机：拍摄完把照片回传给页面 */
        @JavascriptInterface
        fun takePhoto() {
            runOnUiThread { launchCamera() }
        }

        /**
         * 清除缓存：删掉 cacheDir 里的暂存文件（比如导入用的 zip），并清 WebView 缓存。
         * 会话、附件原件、设置都在 IndexedDB / localStorage 里，不受影响。
         * 返回释放的空间大小，页面直接显示。
         */
        @JavascriptInterface
        fun clearCache(): String {
            var freed = 0L
            val stack = ArrayDeque<File>()
            cacheDir?.let { stack.addLast(it) }
            while (stack.isNotEmpty()) {
                val dir = stack.removeLast()
                val children = dir.listFiles() ?: continue
                for (child in children) {
                    if (child.isDirectory) {
                        stack.addLast(child)
                    } else {
                        freed += child.length()
                    }
                    child.delete()
                }
            }
            runOnUiThread { if (::webView.isInitialized) webView.clearCache(true) }
            return Formatter.formatShortFileSize(this@MainActivity, freed)
        }

        /** 页面背景色回传，用来同步状态栏和导航栏 */
        @JavascriptInterface
        fun setChromeColor(hex: String) {
            val color = try {
                Color.parseColor(hex)
            } catch (_: IllegalArgumentException) {
                return
            }
            runOnUiThread { applySystemBars(color) }
        }

        @JavascriptInterface
        fun saveBase64(name: String, mimeType: String, base64: String) {
            Thread {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, sanitize(name))
                        put(MediaStore.Downloads.MIME_TYPE, mimeType.ifBlank { "application/octet-stream" })
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("MediaStore 拒绝了写入")
                    resolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: throw IllegalStateException("无法打开输出流")
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    toast(getString(R.string.saved_to_downloads, sanitize(name)))
                } catch (error: Exception) {
                    toast(getString(R.string.save_failed, error.message ?: error.javaClass.simpleName))
                }
            }.start()
        }

        @JavascriptInterface
        fun reportError(message: String) {
            toast(getString(R.string.save_failed, message))
        }
    }

    /** 边到边下系统栏是透明的，这里只切换图标明暗，不再改颜色 */
    @Suppress("DEPRECATION")
    private fun applySystemBars(color: Int) {
        val light = isLightColor(color)
        var flags = window.decorView.systemUiVisibility
        flags = if (light) {
            flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        } else {
            flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        }
        window.decorView.systemUiVisibility = flags
    }

    private fun isLightColor(color: Int): Boolean {
        fun channel(value: Int): Double {
            val normalized = value / 255.0
            return if (normalized <= 0.03928) {
                normalized / 12.92
            } else {
                Math.pow((normalized + 0.055) / 1.055, 2.4)
            }
        }
        val luminance = 0.2126 * channel(color shr 16 and 0xFF) +
            0.7152 * channel(color shr 8 and 0xFF) +
            0.0722 * channel(color and 0xFF)
        return luminance > 0.5
    }

    private fun sanitize(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_").takeIf { it.isNotBlank() } ?: "export.zip"

    private fun toast(message: String) {
        runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
    }

    private fun openExternally(uri: Uri): Boolean = try {
        startActivity(Intent(Intent.ACTION_VIEW, uri))
        true
    } catch (_: ActivityNotFoundException) {
        true
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidBridge")
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!::webView.isInitialized) {
            super.onBackPressed()
            return
        }
        // 键盘展开时先收键盘：这是最符合直觉的第一下
        if (isKeyboardVisible()) {
            hideKeyboard()
            return
        }
        // 页面负责关弹窗、收抽屉、回到新对话；它不处理时才轮到我们退出
        webView.evaluateJavascript(BACK_SCRIPT) { value ->
            if (value == "true") {
                return@evaluateJavascript
            }
            val now = System.currentTimeMillis()
            if (now - lastBackAt < 2000) {
                finish()
            } else {
                lastBackAt = now
                toast(getString(R.string.back_again_to_exit))
            }
        }
    }

    private fun isKeyboardVisible(): Boolean {
        val visible = Rect()
        window.decorView.getWindowVisibleDisplayFrame(visible)
        val root = window.decorView.rootView.height
        return root > 0 && root - visible.height() > root * 0.15
    }

    private fun hideKeyboard() {
        val manager = getSystemService(InputMethodManager::class.java) ?: return
        manager.hideSoftInputFromWindow(webView.windowToken, 0)
    }
}
