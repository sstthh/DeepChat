import { create } from 'zustand'

type SystemPromptDialogState = {
  open: boolean
  /** 目标会话；null 表示「新建会话」时的草稿，此时提示词在首条消息发出时生效 */
  sessionId: string | null
}

export const useSystemPromptDialog = create<SystemPromptDialogState>(() => ({
  open: false,
  sessionId: null
}))

export const openSystemPromptDialog = (sessionId: string | null) =>
  useSystemPromptDialog.setState({ open: true, sessionId })

export const closeSystemPromptDialog = () =>
  useSystemPromptDialog.setState({ open: false, sessionId: null })
