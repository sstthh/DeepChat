# 本项目不启用混淆，保留占位文件供后续开启 minify 时使用。
-keepclassmembers class io.github.chatdemoshell.MainActivity$Bridge {
    public *;
}
