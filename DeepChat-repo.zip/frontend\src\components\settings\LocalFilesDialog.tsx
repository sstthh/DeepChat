import { useCallback, useEffect, useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import { deleteFileBlob } from '../../services/chat/db.js'
import { collectLocalFiles, type LocalFileEntry } from '../../services/chat/localFiles.js'
import { selectSession } from '../../services/chat/store.js'
import { formatBytes } from '../../utils/format.js'
import { Button } from '../base/Button.js'
import { Modal } from '../base/Modal.js'
import { showToast } from '../base/toastState.js'
import { closeSettings } from './settingsDialogState.js'
import styles from './LocalFilesDialog.module.css'

/** 手动管理本地附件原件：看占用、看被哪些会话引用、按需删除 */
export const LocalFilesDialog = ({ onClose }: { onClose: () => void }) => {
  const t = useTranslate()
  const [entries, setEntries] = useState<LocalFileEntry[] | null>(null)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    setEntries(await collectLocalFiles())
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const total = entries?.reduce((sum, entry) => sum + entry.size, 0) ?? 0
  const orphans = entries?.filter((entry) => entry.count === 0) ?? []

  const remove = async (entry: LocalFileEntry) => {
    if (busy) {
      return
    }
    setBusy(true)
    try {
      await deleteFileBlob(entry.id)
      setEntries((current) => (current ?? []).filter((item) => item.id !== entry.id))
      showToast({ key: 'localFileDeleted' })
    } catch {
      showToast({ key: 'localFileDeleteFailed', type: 'error' })
    } finally {
      setBusy(false)
    }
  }

  const cleanOrphans = async () => {
    if (busy || orphans.length === 0) {
      return
    }
    setBusy(true)
    try {
      for (const entry of orphans) {
        await deleteFileBlob(entry.id)
      }
      await load()
      showToast({ key: 'localFileCleaned' })
    } catch {
      showToast({ key: 'localFileDeleteFailed', type: 'error' })
    } finally {
      setBusy(false)
    }
  }

  const openSession = (id: string) => {
    selectSession(id)
    onClose()
    closeSettings()
  }

  return (
    <Modal
      title={t('localFilesTitle')}
      closable
      className={styles.dialog}
      mainClassName={styles.main}
      onClose={onClose}
      footer={
        <>
          <span className={styles.summary}>
            {entries
              ? t('localFilesSummary', {
                  count: entries.length,
                  size: formatBytes(total),
                })
              : t('localFilesLoading')}
          </span>
          {orphans.length > 0 ? (
            <Button variant="outlined" size="m" disabled={busy} onClick={() => void cleanOrphans()}>
              {t('localFilesCleanOrphans', { count: orphans.length })}
            </Button>
          ) : null}
          <Button variant="outlined" size="m" onClick={onClose}>
            {t('close')}
          </Button>
        </>
      }
    >
      <div className={styles.hint}>{t('localFilesHint')}</div>
      {entries && entries.length === 0 ? (
        <div className={styles.empty}>{t('localFilesEmpty')}</div>
      ) : (
        <div className={styles.list}>
          {(entries ?? []).map((entry) => (
            <div key={entry.id} className={styles.row}>
              <div className={styles.info}>
                <div className={styles.name} title={entry.name || entry.id}>
                  {entry.name || entry.id}
                </div>
                <div className={styles.meta}>
                  {formatBytes(entry.size)}
                  {' · '}
                  <span className={entry.count === 0 ? styles.orphan : undefined}>
                    {entry.count === 0
                      ? t('localFilesOrphan')
                      : t('localFilesUsage', { count: entry.sessions.length })}
                  </span>
                </div>
                {entry.sessions.length > 0 ? (
                  <div className={styles.sessions}>
                    {entry.sessions.map((session) => (
                      <button
                        key={session.id}
                        type="button"
                        className={styles.session}
                        title={session.title || t('untitledChat')}
                        onClick={() => openSession(session.id)}
                      >
                        {session.title || t('untitledChat')}
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
              <Button
                variant="dangerOutlined"
                size="s"
                disabled={busy}
                onClick={() => void remove(entry)}
              >
                {t('delete')}
              </Button>
            </div>
          ))}
        </div>
      )}
    </Modal>
  )
}
