/**
 * 录音并编码为 ASR 接受的 WAV（单声道、16-bit PCM、16kHz）。
 *
 * 优先以 16kHz 创建 AudioContext，浏览器负责重采样；部分 Android WebView 不接受
 * 自定义采样率，这时退回设备默认采样率，采集完成后在本地做线性重采样。
 */

/** ASR 要求的采样率 */
export const SAMPLE_RATE = 16000
/** ASR 单次时长上限 120 秒 */
export const MAX_SECONDS = 120

const BUFFER_SIZE = 4096

export type Recording = {
  /** 停止录音并返回 WAV；没有采到声音时返回 null */
  stop: () => Promise<Blob | null>
  /** 放弃录音，释放麦克风 */
  cancel: () => void
  /** 频谱分析节点，只读；采样率与录音一致 */
  analyser: AnalyserNode
}

/** 优先申请带降噪的约束；部分 WebView 会因音频处理参数采不到数据，退回默认约束 */
const openMicrophone = async (): Promise<MediaStream> => {
  try {
    return await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true },
    })
  } catch (error) {
    const name = error instanceof DOMException ? error.name : ''
    if (name === 'NotReadableError' || name === 'OverconstrainedError' || name === 'AbortError') {
      return navigator.mediaDevices.getUserMedia({ audio: true })
    }
    throw error
  }
}

/** 开始录音；到达时长上限时调用 onLimit，由调用方决定何时 stop */
export const startRecording = async (onLimit: () => void): Promise<Recording> => {
  const stream = await openMicrophone()
  let context: AudioContext | undefined
  let source: MediaStreamAudioSourceNode | undefined
  let processor: ScriptProcessorNode | undefined
  let analyser: AnalyserNode | undefined
  let released = false

  const release = () => {
    if (released) {
      return
    }
    released = true
    if (processor) {
      processor.onaudioprocess = null
    }
    // 初始化可能只完成了一部分；单个节点断开失败也不能阻止麦克风释放。
    for (const node of [processor, analyser, source]) {
      try {
        node?.disconnect()
      } catch {
        // 继续释放其余资源。
      }
    }
    for (const track of stream.getTracks()) {
      track.stop()
    }
    void context?.close().catch(() => {})
  }

  try {
    try {
      context = new AudioContext({ sampleRate: SAMPLE_RATE })
    } catch {
      context = new AudioContext()
    }
    const inputRate = context.sampleRate
    source = context.createMediaStreamSource(stream)
    processor = context.createScriptProcessor(BUFFER_SIZE, 1, 1)
    // 频谱分析用：串在录音链路中间（原样透传），WebKit 不会处理未连到输出的分析节点
    analyser = context.createAnalyser()
    analyser.fftSize = 512
    analyser.smoothingTimeConstant = 0.2
    const chunks: Float32Array[] = []
    let length = 0
    let limited = false
    processor.onaudioprocess = (event) => {
      if (limited) {
        return
      }
      const channel = event.inputBuffer.getChannelData(0)
      chunks.push(new Float32Array(channel))
      length += channel.length
      if (length >= MAX_SECONDS * inputRate) {
        limited = true
        onLimit()
      }
    }
    source.connect(analyser)
    analyser.connect(processor)
    // ScriptProcessorNode 只有连到输出才会持续回调；输出缓冲保持静音
    processor.connect(context.destination)
    // 在 await getUserMedia 之后创建，iOS 上可能处于 suspended
    if (context.state === 'suspended') {
      void context.resume().catch(() => {})
    }

    return {
      stop: async () => {
        release()
        return length === 0 ? null : encodeWav(chunks, length, inputRate)
      },
      cancel: release,
      analyser,
    }
  } catch (error) {
    release()
    throw error
  }
}

/** 线性插值重采样；只在设备不支持 16kHz 采集时用到 */
const resample = (input: Float32Array, from: number, to: number): Float32Array => {
  const ratio = from / to
  const length = Math.floor(input.length / ratio)
  const output = new Float32Array(length)
  for (let i = 0; i < length; i++) {
    const position = i * ratio
    const index = Math.floor(position)
    const fraction = position - index
    const current = input[index]
    const next = index + 1 < input.length ? input[index + 1] : current
    output[i] = current + (next - current) * fraction
  }
  return output
}

const encodeWav = (chunks: Float32Array[], length: number, inputRate: number) => {
  const limit = Math.min(length, MAX_SECONDS * inputRate)
  const merged = new Float32Array(limit)
  let offset = 0
  for (const chunk of chunks) {
    const take = Math.min(chunk.length, limit - offset)
    if (take <= 0) {
      break
    }
    merged.set(take === chunk.length ? chunk : chunk.subarray(0, take), offset)
    offset += take
  }
  const samples =
    inputRate === SAMPLE_RATE ? merged : resample(merged, inputRate, SAMPLE_RATE)

  const buffer = new ArrayBuffer(44 + samples.length * 2)
  const view = new DataView(buffer)
  const writeString = (at: number, text: string) => {
    for (let i = 0; i < text.length; i++) {
      view.setUint8(at + i, text.charCodeAt(i))
    }
  }
  writeString(0, 'RIFF')
  view.setUint32(4, 36 + samples.length * 2, true)
  writeString(8, 'WAVE')
  writeString(12, 'fmt ')
  view.setUint32(16, 16, true)
  view.setUint16(20, 1, true) // PCM
  view.setUint16(22, 1, true) // 单声道
  view.setUint32(24, SAMPLE_RATE, true)
  view.setUint32(28, SAMPLE_RATE * 2, true)
  view.setUint16(32, 2, true)
  view.setUint16(34, 16, true)
  writeString(36, 'data')
  view.setUint32(40, samples.length * 2, true)
  let at = 44
  for (let i = 0; i < samples.length; i++) {
    const sample = Math.max(-1, Math.min(1, samples[i]))
    view.setInt16(at, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true)
    at += 2
  }
  return new Blob([buffer], { type: 'audio/wav' })
}
