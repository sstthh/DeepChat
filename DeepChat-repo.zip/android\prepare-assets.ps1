#Requires -Version 5.1
<#
.SYNOPSIS
    Copy a built chat-demo bundle into app/src/main/assets/www.

.DESCRIPTION
    Accepts either a folder (the contents of chat-demo's dist/) or the .zip from
    GitHub Releases. Everything currently under assets/www is deleted first, so
    the placeholder page disappears once you run this.

.EXAMPLE
    .\prepare-assets.ps1 -Dist .\chat-demo\dist

.EXAMPLE
    .\prepare-assets.ps1 -Dist "$env:USERPROFILE\Downloads\chat-demo-0.1.3.zip"
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$Dist
)

$ErrorActionPreference = 'Stop'

$root = (Resolve-Path $PSScriptRoot).Path
$www = [System.IO.Path]::GetFullPath((Join-Path $root 'app\src\main\assets\www'))

# Guard: never delete outside this project.
if (-not $www.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to write outside the project directory: $www"
}

if (-not (Test-Path -LiteralPath $Dist)) {
    throw "Path not found: $Dist"
}
$src = (Resolve-Path -LiteralPath $Dist).Path

$tempDir = $null
if (Test-Path -LiteralPath $src -PathType Leaf) {
    if ([System.IO.Path]::GetExtension($src) -ne '.zip') {
        throw "Expected a directory or a .zip file, got: $src"
    }
    $tempDir = Join-Path ([System.IO.Path]::GetTempPath()) ("chat-demo-dist-" + [Guid]::NewGuid().ToString('N'))
    Write-Host "Extracting $src"
    Expand-Archive -LiteralPath $src -DestinationPath $tempDir -Force
    $src = $tempDir
}

# Allow the zip to wrap the bundle in one top-level folder.
if (-not (Test-Path -LiteralPath (Join-Path $src 'index.html'))) {
    $nested = Get-ChildItem -LiteralPath $src -Directory |
        Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'index.html') } |
        Select-Object -First 1
    if ($nested) { $src = $nested.FullName }
}

$index = Join-Path $src 'index.html'
if (-not (Test-Path -LiteralPath $index)) {
    throw "index.html not found in $src - is this really a chat-demo build output?"
}

New-Item -ItemType Directory -Path $www -Force | Out-Null
Get-ChildItem -LiteralPath $www -Force | Remove-Item -Recurse -Force

Copy-Item -Path (Join-Path $src '*') -Destination $www -Recurse -Force

if ($tempDir -and (Test-Path -LiteralPath $tempDir)) {
    Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
}

$files = Get-ChildItem -LiteralPath $www -Recurse -File
$sizeMb = [math]::Round((($files | Measure-Object -Property Length -Sum).Sum / 1MB), 2)
Write-Host "OK: $($files.Count) files, $sizeMb MB -> app/src/main/assets/www"
