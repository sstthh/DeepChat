plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// 远程模式：构建时传 -PchatDemoUrl=https://cdn.deepseek.com/chat-demo/
// 留空 = 使用 assets 里内置的静态站点（断网可用，但更新要重新打包）
val chatDemoUrl: String = (project.findProperty("chatDemoUrl") as String?)?.trim().orEmpty()

android {
    namespace = "io.github.chatdemoshell"
    compileSdk = 35

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        applicationId = "io.github.chatdemoshell"
        minSdk = 29
        // 停在 34：targetSdk 35 会在 Android 15 上强制 edge-to-edge，
        // WebView 内容会压到状态栏下面，这里不做 inset 处理就保持 34。
        targetSdk = 34
        versionCode = 21
        versionName = "3.1"

        buildConfigField("String", "CHAT_DEMO_URL", "\"$chatDemoUrl\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // 只为了 WebViewAssetLoader：把本地静态文件挂在 https:// 源上，
    // IndexedDB / localStorage 才能拿到稳定 origin。
    implementation("androidx.webkit:webkit:1.12.1")
    // FileProvider：把选中的 zip 复制到私有目录后，再以 content:// 交给页面
    implementation("androidx.core:core:1.13.1")
}
