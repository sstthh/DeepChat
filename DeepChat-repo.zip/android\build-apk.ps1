#Requires -Version 5.1
<#
.SYNOPSIS
    Build the chat-demo Android shell (debug APK by default).

.DESCRIPTION
    Resolves a JDK, an Android SDK and Gradle, writes local.properties, then runs
    the requested Gradle task. Nothing is downloaded automatically.

.PARAMETER Jdk
    JDK 17+ home. Defaults to JAVA_HOME, then Android Studio's bundled JBR.

.PARAMETER Sdk
    Android SDK root. Defaults to ANDROID_HOME / ANDROID_SDK_ROOT / %LOCALAPPDATA%\Android\Sdk.

.PARAMETER Gradle
    gradle.bat to use. Defaults to gradle on PATH, then a Gradle 8.11.1 wrapper dist.

.PARAMETER Remote
    Load the web app from this URL instead of bundling it into the APK.
    e.g. -Remote https://cdn.deepseek.com/chat-demo/
    Remote mode is always up to date but needs a network connection.

.EXAMPLE
    .\build-apk.ps1

.EXAMPLE
    .\build-apk.ps1 -Remote https://cdn.deepseek.com/chat-demo/

.EXAMPLE
    .\build-apk.ps1 -GradleTask assembleRelease
#>
[CmdletBinding()]
param(
    [string]$Jdk,
    [string]$Gradle,
    [string]$Sdk,
    [string]$Remote,
    [string]$GradleTask = 'assembleDebug'
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path $PSScriptRoot).Path

function Test-Jdk([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return $false }
    return Test-Path -LiteralPath (Join-Path $path 'bin\java.exe')
}

function Resolve-Jdk([string]$explicit) {
    $candidates = @(
        $explicit,
        $env:JAVA_HOME,
        'C:\Program Files\Android\Android Studio\jbr',
        (Join-Path $env:LOCALAPPDATA 'Programs\Android Studio\jbr'),
        'C:\Program Files\Android\Android Studio\jre'
    )
    $java = Get-Command java -ErrorAction SilentlyContinue
    if ($java -and $java.Source) {
        $candidates += (Split-Path (Split-Path $java.Source -Parent) -Parent)
    }
    foreach ($candidate in $candidates) {
        if (Test-Jdk $candidate) { return (Resolve-Path -LiteralPath $candidate).Path }
    }
    return $null
}

function Resolve-Sdk([string]$explicit) {
    $candidates = @(
        $explicit,
        $env:ANDROID_HOME,
        $env:ANDROID_SDK_ROOT,
        (Join-Path $env:LOCALAPPDATA 'Android\Sdk')
    )
    foreach ($candidate in $candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) { continue }
        if (Test-Path -LiteralPath (Join-Path $candidate 'platforms')) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    return $null
}

function Resolve-Gradle([string]$explicit) {
    if (-not [string]::IsNullOrWhiteSpace($explicit)) {
        if (-not (Test-Path -LiteralPath $explicit)) { throw "Gradle not found: $explicit" }
        return (Resolve-Path -LiteralPath $explicit).Path
    }
    $command = Get-Command gradle -ErrorAction SilentlyContinue
    if ($command -and $command.Source) { return $command.Source }

    $dists = Join-Path $env:USERPROFILE '.gradle\wrapper\dists'
    if (Test-Path -LiteralPath $dists) {
        $hit = Get-ChildItem -LiteralPath $dists -Directory -Filter 'gradle-8.11.1-bin' -ErrorAction SilentlyContinue |
            ForEach-Object { Join-Path $_.FullName 'gradle-8.11.1\bin\gradle.bat' } |
            Where-Object { Test-Path -LiteralPath $_ } |
            Select-Object -First 1
        if ($hit) { return $hit }
    }
    return $null
}

$jdkPath = Resolve-Jdk $Jdk
if (-not $jdkPath) {
    Write-Host ''
    Write-Host 'No JDK found. Pick one of:' -ForegroundColor Yellow
    Write-Host '  1. Install Android Studio (ships a JDK under ...\Android Studio\jbr)'
    Write-Host '  2. Install a JDK 17 and set JAVA_HOME'
    Write-Host '  3. Pass -Jdk "C:\path\to\jdk"'
    Write-Host ''
    exit 1
}

$sdkPath = Resolve-Sdk $Sdk
if (-not $sdkPath) {
    Write-Host ''
    Write-Host 'No Android SDK found. Pick one of:' -ForegroundColor Yellow
    Write-Host '  1. Install Android Studio and let it install the SDK'
    Write-Host '  2. Install the command line tools and set ANDROID_HOME'
    Write-Host '  3. Pass -Sdk "C:\path\to\Sdk"'
    Write-Host ''
    exit 1
}

$gradlePath = Resolve-Gradle $Gradle
if (-not $gradlePath) {
    Write-Host ''
    Write-Host 'No Gradle found. Pick one of:' -ForegroundColor Yellow
    Write-Host '  1. Install Android Studio and open this folder once (it downloads Gradle 8.11.1)'
    Write-Host '  2. Install Gradle 8.11.1 and put it on PATH'
    Write-Host '  3. Pass -Gradle "C:\path\to\gradle-8.11.1\bin\gradle.bat"'
    Write-Host ''
    exit 1
}

$escapedSdk = $sdkPath.Replace('\', '\\').Replace(':', '\:')
Set-Content -LiteralPath (Join-Path $root 'local.properties') -Value "sdk.dir=$escapedSdk" -Encoding ASCII

$remoteMode = -not [string]::IsNullOrWhiteSpace($Remote)
if (-not $remoteMode -and (Test-Path -LiteralPath (Join-Path $root 'app\src\main\assets\www\PLACEHOLDER.txt'))) {
    Write-Warning 'assets/www still holds the placeholder page. Run: .\prepare-assets.ps1 -Dist <chat-demo dist or release zip>'
}

Write-Host "JDK    : $jdkPath"
Write-Host "SDK    : $sdkPath"
Write-Host "Gradle : $gradlePath"
Write-Host "Task   : $GradleTask"
if ($remoteMode) {
    Write-Host "Mode   : remote -> $($Remote.Trim())"
} else {
    Write-Host 'Mode   : bundled assets (offline capable)'
}
Write-Host ''

$env:JAVA_HOME = $jdkPath
$originalPath = $env:PATH
$env:PATH = (Join-Path $jdkPath 'bin') + ';' + $env:PATH
try {
    Push-Location -LiteralPath $root
    $gradleArgs = @('--no-daemon')
    if ($remoteMode) {
        $gradleArgs += "-PchatDemoUrl=$($Remote.Trim())"
    }
    $gradleArgs += $GradleTask
    & $gradlePath @gradleArgs
    $exitCode = $LASTEXITCODE
} finally {
    Pop-Location
    $env:PATH = $originalPath
}

if ($exitCode -ne 0) {
    Write-Host ''
    Write-Error "Gradle failed with exit code $exitCode"
    exit $exitCode
}

$apk = Get-ChildItem -LiteralPath (Join-Path $root 'app\build\outputs\apk') -Recurse -Filter '*.apk' -ErrorAction SilentlyContinue |
    Sort-Object -Property LastWriteTime -Descending |
    Select-Object -First 1
if ($apk) {
    Write-Host ''
    Write-Host ("APK: {0} ({1} MB)" -f $apk.FullName, [math]::Round($apk.Length / 1MB, 2)) -ForegroundColor Green
} else {
    Write-Warning 'Build finished but no APK was found under app/build/outputs/apk.'
}
