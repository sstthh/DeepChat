# Android 壳

把 `frontend/` 构建出的静态站点打进一个最小 WebView 容器。

## 构建步骤

```powershell
# 1. 构建前端（在仓库根的 frontend/ 目录）
pnpm install
pnpm build

# 2. 把产物拷进 assets
.\prepare-assets.ps1 -Dist ..\frontend\dist

# 3. 构建
.\build-apk.ps1
```

产物在 `app\build\outputs\apk\debug\app-debug.apk`。

`build-apk.ps1` 会自动探测 JDK、Android SDK 和 Gradle，也可以显式指定：

```powershell
.\build-apk.ps1 -Jdk "C:\Program Files\Android\Android Studio\jbr" `
               -Sdk "$env:LOCALAPPDATA\Android\Sdk" `
               -Gradle "C:\gradle-8.11.1\bin\gradle.bat"
```

用 Android Studio 打开本目录也可以直接构建。

## 两种模式

| | 内置（默认） | 远程 |
|---|---|---|
| 页面来源 | `assets/www` | `-PchatDemoUrl=<url>` |
| 断网 | 界面能开 | 白屏 |
| 更新 | 重新打包 | 自动 |

```powershell
.\build-apk.ps1 -Remote https://cdn.deepseek.com/chat-demo/
```

## 实现要点

| 问题 | 做法 |
| --- | --- |
| `file://` 下 IndexedDB 不可靠 | `WebViewAssetLoader` 把 assets 挂到 `https://appassets.androidplatform.net/assets/www/`，页面拿到正常 https origin |
| 附件上传按钮无反应 | `WebChromeClient.onShowFileChooser` + `startActivityForResult`，支持多选 |
| 语音输入不可用 | `onPermissionRequest` 两段式：先申请 `RECORD_AUDIO`，授权后再 `request.grant()`；补 `MODIFY_AUDIO_SETTINGS` |
| 大 zip 导入极慢 | 选中后原生复制到私有目录再交给页面，绕开 SAF 的随机读开销；只对 `.zip` 生效，避免改掉其它附件的文件名 |
| 导出 ZIP（`blob:`）拿不到内容 | `DownloadListener` 只能拿到 blob URL，反注入 JS 读成 base64 写进系统「下载」 |
| 返回键直接退出 | 页面暴露 `window.__deepChatBack()`，壳逐级询问：键盘 → 弹窗 → 抽屉 → 新对话 → 双击退出 |
| 拍照 | `ACTION_IMAGE_CAPTURE` + FileProvider 输出原图，压到长边 2048 后 base64 回传页面 |
| 状态栏白边 | 边到边：系统栏透明，把 inset 高度写成 CSS 变量交给页面留白 |
| 页面被双指缩放 | viewport meta 禁用页面缩放，图片查看器内部自己实现手势 |

## 目录

```
app/src/main/
├─ java/io/github/…/MainActivity.kt   壳的全部逻辑（单文件）
├─ assets/www/                        前端产物（当前是占位页）
└─ res/                               主题、矢量图标、FileProvider 路径
```
