import * as db from './db.js'

export type LocalFileSession = { id: string; title: string }

export type LocalFileEntry = {
  id: string
  /** 取自第一条引用它的附件记录；孤立原件没有名字 */
  name: string
  size: number
  type: string
  /** 引用它的会话（去重） */
  sessions: LocalFileSession[]
  /** 被多少条消息附件引用 */
  count: number
}

/**
 * 汇总本地原件及引用关系。只读 blob 的元信息，不把字节读进内存；
 * 引用关系来自各会话里 user 消息的附件列表。
 */
export const collectLocalFiles = async (): Promise<LocalFileEntry[]> => {
  const blobs = await db.listFileBlobs()
  if (blobs.length === 0) {
    return []
  }
  const entries = new Map<string, LocalFileEntry>()
  for (const blob of blobs) {
    entries.set(blob.id, {
      id: blob.id,
      name: '',
      size: blob.size,
      type: blob.type,
      sessions: [],
      count: 0,
    })
  }
  for (const summary of await db.loadSessionSummaries()) {
    const session = await db.loadSession(summary.id)
    if (!session) {
      continue
    }
    const seen = new Set<string>()
    for (const message of session.messages) {
      if (message.role !== 'user') {
        continue
      }
      for (const file of message.files) {
        const entry = entries.get(file.id)
        if (!entry) {
          continue
        }
        entry.count += 1
        if (!entry.name) {
          entry.name = file.name
        }
        if (!seen.has(file.id)) {
          seen.add(file.id)
          entry.sessions.push({
            id: session.id,
            title: session.title || summary.title,
          })
        }
      }
    }
  }
  return [...entries.values()].sort((a, b) => b.size - a.size)
}
