import { useCallback, useEffect, useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import { deleteFile, listFiles } from '../../services/api/client.js'
import { useSettings } from '../../services/settings.js'
import { formatBytes, formatDate } from '../../utils/format.js'
import { Button } from '../base/Button.js'
import { Modal } from '../base/Modal.js'
import { showToast } from '../base/toastState.js'
import type { FileObject } from '../../services/api/types.js'
import styles from './FileManagerDialog.module.css'

/** 文件归账号所有，跨会话共享；这里直接对 Files API 做列表和删除 */
export const FileManagerDialog = ({ onClose }: { onClose: () => void }) => {
  const t = useTranslate()
  const apiKey = useSettings((state) => state.apiKey)
  const [files, setFiles] = useState<FileObject[] | null>(null)
  const [failed, setFailed] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)

  const load = useCallback(async () => {
    if (!apiKey) {
      return
    }
    setFailed(false)
    try {
      const collected: FileObject[] = []
      let afterId: string | undefined
      // 逐页取完；单页上限 1000，这里用 100 让首屏更快出来
      for (let page = 0; page < 100; page += 1) {
        const result = await listFiles(apiKey, { afterId, limit: 100 })
        collected.push(...result.data)
        setFiles([...collected])
        if (!result.has_more || !result.last_id) {
          break
        }
        afterId = result.last_id
      }
      setFiles(collected)
    } catch {
      setFailed(true)
      setFiles([])
    }
  }, [apiKey])

  useEffect(() => {
    void load()
  }, [load])

  const total = files?.reduce((sum, file) => sum + (file.size_bytes || 0), 0) ?? 0

  const remove = async (file: FileObject) => {
    if (!apiKey || busyId) {
      return
    }
    setBusyId(file.id)
    try {
      await deleteFile(apiKey, file.id)
      setFiles((current) => (current ?? []).filter((item) => item.id !== file.id))
      showToast({ key: 'fileDeleted' })
    } catch {
      showToast({ key: 'fileDeleteFailed', type: 'error' })
    } finally {
      setBusyId(null)
    }
  }

  return (
    <Modal
      title={t('fileManagerTitle')}
      closable
      className={styles.dialog}
      mainClassName={styles.main}
      onClose={onClose}
      footer={
        <>
          <span className={styles.summary}>
            {files
              ? t('fileManagerSummary', { count: files.length, size: formatBytes(total) })
              : t('fileManagerLoading')}
          </span>
          <Button variant="outlined" size="m" onClick={onClose}>
            {t('close')}
          </Button>
        </>
      }
    >
      <div className={styles.hint}>{t('fileManagerHint')}</div>
      {failed ? <div className={styles.error}>{t('fileManagerFailed')}</div> : null}
      {files && files.length === 0 && !failed ? (
        <div className={styles.empty}>{t('fileManagerEmpty')}</div>
      ) : (
        <div className={styles.list}>
          {(files ?? []).map((file) => (
            <div key={file.id} className={styles.row}>
              <div className={styles.info}>
                <div className={styles.name} title={file.filename}>
                  {file.filename || file.id}
                </div>
                <div className={styles.meta}>
                  {formatBytes(file.size_bytes || 0)}
                  {' · '}
                  {formatDate(file.created_at) ?? ''}
                  {file.mime_type ? ` · ${file.mime_type}` : ''}
                </div>
              </div>
              <Button
                variant="dangerOutlined"
                size="s"
                disabled={busyId !== null}
                onClick={() => void remove(file)}
              >
                {t('delete')}
              </Button>
            </div>
          ))}
        </div>
      )}
    </Modal>
  )
}
