import { create } from 'zustand'

type ImageViewerState = {
  url: string | null
  name: string
}

export const useImageViewer = create<ImageViewerState>(() => ({
  url: null,
  name: ''
}))

export const openImageViewer = (url: string, name: string) =>
  useImageViewer.setState({ url, name })

export const closeImageViewer = () => useImageViewer.setState({ url: null, name: '' })
